<?php

namespace App\Services;

use App\Services\BaseServiceClass;
use Illuminate\Http\Request;

class CityService extends BaseServiceClass
{
   
}