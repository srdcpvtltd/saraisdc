<?php

namespace App\Services;

use App\Services\BaseServiceClass;
use Illuminate\Http\Request;

class StateService extends BaseServiceClass
{
   
}