<?php 
 $conn = mysqli_connect("localhost:3306","root","","personality");
 if(!$conn)
 {
  echo "Connection invalid";
  exit();	
 }
 else{
 	
 }
?>