<footer class="c-footer">
    <div> &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>.</div>
    <div class="ml-auto">Powered by&nbsp;<a href="#" target="_new">Infyson Technology Private Limited</a></div>
</footer>
<?php /**PATH C:\xampp\htdocs\sarai\resources\views/partial/footer.blade.php ENDPATH**/ ?>