
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.css')); ?>">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

<?php /**PATH C:\xampp\htdocs\sarai_new\resources\views/layouts/datatables_css.blade.php ENDPATH**/ ?>