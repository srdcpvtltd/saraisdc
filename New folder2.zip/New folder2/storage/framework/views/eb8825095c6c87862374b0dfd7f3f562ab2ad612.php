















<?php /**PATH C:\xampp\htdocs\sarai\resources\views/layouts/menu.blade.php ENDPATH**/ ?>