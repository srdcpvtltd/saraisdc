
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.css')); ?>">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

<?php /**PATH /home/u768597266/domains/srdcdemo.co.in/public_html/sarai/resources/views/layouts/datatables_css.blade.php ENDPATH**/ ?>