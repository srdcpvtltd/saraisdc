<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/buttons.server-side.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\sarai\resources\views/layouts/datatables_js.blade.php ENDPATH**/ ?>