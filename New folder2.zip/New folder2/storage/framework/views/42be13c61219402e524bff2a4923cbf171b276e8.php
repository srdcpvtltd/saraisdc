















<?php /**PATH C:\wamp64\www\sarai_new\resources\views/layouts/menu.blade.php ENDPATH**/ ?>