<footer class="c-footer">
    <div> &copy; {{ date('Y') }} {{ config('app.name') }}.</div>
    <div class="ml-auto">Powered by&nbsp;<a href="#" target="_new">Infyson Technology Private Limited</a></div>
</footer>
