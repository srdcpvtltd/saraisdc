@component('mail::message')
{{__('# Introduction')}}

{{__('This Mail For Testing')}}


{{__('Thanks,')}}<br>
{{ config('app.name') }}
@endcomponent
