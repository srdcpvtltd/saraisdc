<div class="criminal-image">
    <img width='150px' height='150px' src='{{asset(url('storage/criminals/'.$criminal->photo))}}' />
</div>
